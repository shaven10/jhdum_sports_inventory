-- JHCSC Sports Development IMIS — Database Export
-- Database: jhcsc_sports_inventory
-- Generated: 2026-08-22 23:15:44
-- Tables: 31

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = 'NO_AUTO_VALUE_ON_ZERO';

-- --------------------------------------------------------
-- Table: `announcements`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `announcements`;
CREATE TABLE `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','success','warning','danger') NOT NULL DEFAULT 'info',
  `target_roles` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table: `athlete_courses`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `athlete_courses`;
CREATE TABLE `athlete_courses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `code` varchar(40) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_athlete_course_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `athlete_courses` (`id`, `name`, `code`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('1', 'Bachelor of Elementary Education', 'BEED', '0', '1', '2026-08-16 01:12:37', '2026-08-16 11:56:00');
INSERT INTO `athlete_courses` (`id`, `name`, `code`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('2', 'Bachelor of Secondary Education (English)', 'BSEDENGL', '1', '1', '2026-08-16 01:12:37', '2026-08-16 11:54:16');
INSERT INTO `athlete_courses` (`id`, `name`, `code`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('3', 'Bachelor of Physical Education', 'BPED', '2', '1', '2026-08-16 01:12:37', '2026-08-16 11:56:10');
INSERT INTO `athlete_courses` (`id`, `name`, `code`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('6', 'Bachelor of Science in Information Technology', 'BSIT', '5', '1', '2026-08-16 01:12:37', '2026-08-16 11:56:23');
INSERT INTO `athlete_courses` (`id`, `name`, `code`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('8', 'Bachelor of Science in Agriculture', 'BSA', '7', '1', '2026-08-16 01:12:37', '2026-08-16 11:56:34');
INSERT INTO `athlete_courses` (`id`, `name`, `code`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('12', 'Bachelor of Science in Criminology', 'BSCRIM', '11', '1', '2026-08-16 01:12:37', '2026-08-16 11:55:52');
INSERT INTO `athlete_courses` (`id`, `name`, `code`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('18', 'Bachelor of Secondary Education (Math)', 'BSEDMATH', '3', '1', '2026-08-16 11:53:53', '2026-08-16 11:53:53');
INSERT INTO `athlete_courses` (`id`, `name`, `code`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('19', 'Bachelor of Science in Industrial Security Mgmt.', 'BSISM', '8', '1', '2026-08-16 11:55:26', '2026-08-16 11:55:41');
INSERT INTO `athlete_courses` (`id`, `name`, `code`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('20', 'High School Department', 'HS', '15', '1', '2026-08-16 11:57:13', '2026-08-16 11:57:13');

-- --------------------------------------------------------
-- Table: `audit_logs`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `entity_type` varchar(50) DEFAULT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `new_values` longtext DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table: `borrowing_requests`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `borrowing_requests`;
CREATE TABLE `borrowing_requests` (
  `id` int(11) NOT NULL,
  `request_number` varchar(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `equipment_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `borrow_date` date NOT NULL,
  `return_date` date NOT NULL,
  `purpose` enum('pe_class','training','tournament','practice','event','other') NOT NULL,
  `purpose_details` text DEFAULT NULL,
  `status` enum('pending','approved','rejected','cancelled','checked_out','returned','overdue') NOT NULL DEFAULT 'pending',
  `reviewed_by` int(11) DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `review_notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `request_number` (`request_number`),
  KEY `user_id` (`user_id`),
  KEY `equipment_id` (`equipment_id`),
  KEY `reviewed_by` (`reviewed_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table: `borrowing_transactions`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `borrowing_transactions`;
CREATE TABLE `borrowing_transactions` (
  `id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `transaction_type` enum('checkout','return') NOT NULL,
  `quantity` int(11) NOT NULL,
  `processed_by` int(11) NOT NULL,
  `borrower_verified` tinyint(1) DEFAULT 0,
  `condition_on_return` enum('excellent','good','fair','poor','damaged') DEFAULT NULL,
  `damage_notes` text DEFAULT NULL,
  `transaction_date` datetime NOT NULL DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `request_id` (`request_id`),
  KEY `processed_by` (`processed_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table: `damage_reports`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `damage_reports`;
CREATE TABLE `damage_reports` (
  `id` int(11) NOT NULL,
  `equipment_id` int(11) NOT NULL,
  `request_id` int(11) DEFAULT NULL,
  `reported_by` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `damage_type` enum('minor','major','lost','stolen') NOT NULL,
  `description` text NOT NULL,
  `status` enum('reported','under_review','resolved','written_off') NOT NULL DEFAULT 'reported',
  `resolution_notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `resolved_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `equipment_id` (`equipment_id`),
  KEY `request_id` (`request_id`),
  KEY `reported_by` (`reported_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table: `equipment`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `equipment`;
CREATE TABLE `equipment` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `barcode` varchar(50) DEFAULT NULL,
  `quantity_total` int(11) NOT NULL DEFAULT 0,
  `quantity_available` int(11) NOT NULL DEFAULT 0,
  `quantity_borrowed` int(11) NOT NULL DEFAULT 0,
  `quantity_reserved` int(11) NOT NULL DEFAULT 0,
  `quantity_damaged` int(11) NOT NULL DEFAULT 0,
  `quantity_maintenance` int(11) NOT NULL DEFAULT 0,
  `condition` enum('excellent','good','fair','poor','damaged') NOT NULL DEFAULT 'good',
  `location` varchar(100) DEFAULT 'Sports Office',
  `image` varchar(255) DEFAULT NULL,
  `low_stock_threshold` int(11) NOT NULL DEFAULT 3,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `barcode` (`barcode`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `equipment` (`id`, `category_id`, `name`, `description`, `barcode`, `quantity_total`, `quantity_available`, `quantity_borrowed`, `quantity_reserved`, `quantity_damaged`, `quantity_maintenance`, `condition`, `location`, `image`, `low_stock_threshold`, `is_active`, `created_at`, `updated_at`) VALUES ('1', '1', 'Basketball (Official Size)', 'Spalding official size basketball', 'BB-001', '20', '20', '0', '0', '0', '0', 'good', 'Sports Storage Room A', NULL, '3', '1', '2026-08-16 22:02:17', '2026-08-16 22:02:17');
INSERT INTO `equipment` (`id`, `category_id`, `name`, `description`, `barcode`, `quantity_total`, `quantity_available`, `quantity_borrowed`, `quantity_reserved`, `quantity_damaged`, `quantity_maintenance`, `condition`, `location`, `image`, `low_stock_threshold`, `is_active`, `created_at`, `updated_at`) VALUES ('2', '1', 'Basketball Hoop Net', 'Standard basketball net replacement', 'BB-002', '10', '10', '0', '0', '0', '0', 'good', 'Sports Storage Room A', NULL, '3', '1', '2026-08-16 22:02:17', '2026-08-16 22:02:17');
INSERT INTO `equipment` (`id`, `category_id`, `name`, `description`, `barcode`, `quantity_total`, `quantity_available`, `quantity_borrowed`, `quantity_reserved`, `quantity_damaged`, `quantity_maintenance`, `condition`, `location`, `image`, `low_stock_threshold`, `is_active`, `created_at`, `updated_at`) VALUES ('3', '2', 'Volleyball (Official)', 'Mikasa official volleyball', 'VB-001', '15', '15', '0', '0', '0', '0', 'good', 'Sports Storage Room B', NULL, '3', '1', '2026-08-16 22:02:17', '2026-08-16 22:02:17');
INSERT INTO `equipment` (`id`, `category_id`, `name`, `description`, `barcode`, `quantity_total`, `quantity_available`, `quantity_borrowed`, `quantity_reserved`, `quantity_damaged`, `quantity_maintenance`, `condition`, `location`, `image`, `low_stock_threshold`, `is_active`, `created_at`, `updated_at`) VALUES ('4', '2', 'Volleyball Net', 'Standard volleyball net with poles', 'VB-002', '5', '5', '0', '0', '0', '0', 'good', 'Sports Storage Room B', NULL, '3', '1', '2026-08-16 22:02:17', '2026-08-16 22:02:17');
INSERT INTO `equipment` (`id`, `category_id`, `name`, `description`, `barcode`, `quantity_total`, `quantity_available`, `quantity_borrowed`, `quantity_reserved`, `quantity_damaged`, `quantity_maintenance`, `condition`, `location`, `image`, `low_stock_threshold`, `is_active`, `created_at`, `updated_at`) VALUES ('5', '3', 'Badminton Racket', 'Yonex badminton racket', 'BD-001', '30', '30', '0', '0', '0', '0', 'good', 'Sports Storage Room C', NULL, '3', '1', '2026-08-16 22:02:17', '2026-08-16 22:02:17');
INSERT INTO `equipment` (`id`, `category_id`, `name`, `description`, `barcode`, `quantity_total`, `quantity_available`, `quantity_borrowed`, `quantity_reserved`, `quantity_damaged`, `quantity_maintenance`, `condition`, `location`, `image`, `low_stock_threshold`, `is_active`, `created_at`, `updated_at`) VALUES ('6', '3', 'Shuttlecock (Pack of 12)', 'Feather shuttlecock pack', 'BD-002', '25', '25', '0', '0', '0', '0', 'good', 'Sports Storage Room C', NULL, '3', '1', '2026-08-16 22:02:17', '2026-08-16 22:02:17');
INSERT INTO `equipment` (`id`, `category_id`, `name`, `description`, `barcode`, `quantity_total`, `quantity_available`, `quantity_borrowed`, `quantity_reserved`, `quantity_damaged`, `quantity_maintenance`, `condition`, `location`, `image`, `low_stock_threshold`, `is_active`, `created_at`, `updated_at`) VALUES ('7', '4', 'Running Spikes', 'Track running spikes various sizes', 'AT-001', '12', '12', '0', '0', '0', '0', 'good', 'Sports Storage Room D', NULL, '3', '1', '2026-08-16 22:02:17', '2026-08-16 22:02:17');
INSERT INTO `equipment` (`id`, `category_id`, `name`, `description`, `barcode`, `quantity_total`, `quantity_available`, `quantity_borrowed`, `quantity_reserved`, `quantity_damaged`, `quantity_maintenance`, `condition`, `location`, `image`, `low_stock_threshold`, `is_active`, `created_at`, `updated_at`) VALUES ('8', '4', 'Shot Put (4kg)', 'Standard 4kg shot put', 'AT-002', '6', '6', '0', '0', '0', '0', 'good', 'Sports Storage Room D', NULL, '3', '1', '2026-08-16 22:02:17', '2026-08-16 22:02:17');
INSERT INTO `equipment` (`id`, `category_id`, `name`, `description`, `barcode`, `quantity_total`, `quantity_available`, `quantity_borrowed`, `quantity_reserved`, `quantity_damaged`, `quantity_maintenance`, `condition`, `location`, `image`, `low_stock_threshold`, `is_active`, `created_at`, `updated_at`) VALUES ('9', '5', 'Football/Soccer Ball', 'Adidas football size 5', 'FB-001', '10', '10', '0', '0', '0', '0', 'good', 'Sports Storage Room A', NULL, '3', '1', '2026-08-16 22:02:17', '2026-08-16 22:02:17');
INSERT INTO `equipment` (`id`, `category_id`, `name`, `description`, `barcode`, `quantity_total`, `quantity_available`, `quantity_borrowed`, `quantity_reserved`, `quantity_damaged`, `quantity_maintenance`, `condition`, `location`, `image`, `low_stock_threshold`, `is_active`, `created_at`, `updated_at`) VALUES ('10', '6', 'Table Tennis Paddle', 'Butterfly table tennis paddle', 'TT-001', '20', '20', '0', '0', '0', '0', 'good', 'Sports Storage Room C', NULL, '3', '1', '2026-08-16 22:02:17', '2026-08-16 22:02:17');

-- --------------------------------------------------------
-- Table: `equipment_categories`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `equipment_categories`;
CREATE TABLE `equipment_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `equipment_categories` (`id`, `name`, `description`, `is_active`, `created_at`) VALUES ('1', 'Basketball', 'Basketball equipment and accessories', '1', '2026-08-16 22:02:17');
INSERT INTO `equipment_categories` (`id`, `name`, `description`, `is_active`, `created_at`) VALUES ('2', 'Volleyball', 'Volleyball equipment and accessories', '1', '2026-08-16 22:02:17');
INSERT INTO `equipment_categories` (`id`, `name`, `description`, `is_active`, `created_at`) VALUES ('3', 'Badminton', 'Badminton rackets, shuttlecocks, and nets', '1', '2026-08-16 22:02:17');
INSERT INTO `equipment_categories` (`id`, `name`, `description`, `is_active`, `created_at`) VALUES ('4', 'Athletics', 'Track and field equipment', '1', '2026-08-16 22:02:17');
INSERT INTO `equipment_categories` (`id`, `name`, `description`, `is_active`, `created_at`) VALUES ('5', 'Football', 'Football/soccer equipment', '1', '2026-08-16 22:02:17');
INSERT INTO `equipment_categories` (`id`, `name`, `description`, `is_active`, `created_at`) VALUES ('6', 'Table Tennis', 'Table tennis paddles, balls, and tables', '1', '2026-08-16 22:02:17');
INSERT INTO `equipment_categories` (`id`, `name`, `description`, `is_active`, `created_at`) VALUES ('7', 'Swimming', 'Swimming gear and accessories', '1', '2026-08-16 22:02:17');
INSERT INTO `equipment_categories` (`id`, `name`, `description`, `is_active`, `created_at`) VALUES ('8', 'General Sports', 'General sports equipment and accessories', '1', '2026-08-16 22:02:17');

-- --------------------------------------------------------
-- Table: `incident_reports`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `incident_reports`;
CREATE TABLE `incident_reports` (
  `id` int(11) NOT NULL,
  `reporter_user_id` int(11) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `category` varchar(50) NOT NULL DEFAULT 'query',
  `message` text NOT NULL,
  `status` enum('open','in_progress','resolved','closed') NOT NULL DEFAULT 'open',
  `admin_response` text DEFAULT NULL,
  `responded_by` int(11) DEFAULT NULL,
  `responded_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `responded_by` (`responded_by`),
  KEY `idx_incident_status` (`status`),
  KEY `idx_incident_reporter` (`reporter_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `incident_reports` (`id`, `reporter_user_id`, `subject`, `category`, `message`, `status`, `admin_response`, `responded_by`, `responded_at`, `created_at`, `updated_at`) VALUES ('0', '23', 'bad weather', 'query', 'asdfasf', 'closed', 'afd', '1', '2026-08-22 23:08:29', '2026-08-22 23:08:04', '2026-08-22 23:08:29');

-- --------------------------------------------------------
-- Table: `intramural_athletes`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `intramural_athletes`;
CREATE TABLE `intramural_athletes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `athlete_code` varchar(20) NOT NULL,
  `student_id` varchar(30) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `gender` enum('male','female','other') NOT NULL DEFAULT 'male',
  `birthdate` date DEFAULT NULL,
  `department` varchar(150) DEFAULT NULL,
  `year_level` varchar(20) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `athlete_code` (`athlete_code`),
  UNIQUE KEY `uq_athlete_student_id` (`student_id`),
  KEY `team_id` (`team_id`)
) ENGINE=InnoDB AUTO_INCREMENT=228 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table: `intramural_division_sports`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `intramural_division_sports`;
CREATE TABLE `intramural_division_sports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `division_id` int(11) NOT NULL,
  `sport_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_division_sport` (`division_id`,`sport_id`),
  KEY `sport_id` (`sport_id`)
) ENGINE=InnoDB AUTO_INCREMENT=485 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('427', '1', '1', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('428', '1', '2', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('429', '1', '3', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('430', '1', '4', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('431', '1', '5', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('432', '1', '6', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('433', '1', '7', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('434', '1', '8', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('435', '1', '9', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('436', '1', '10', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('437', '1', '11', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('438', '1', '12', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('439', '1', '13', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('440', '1', '14', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('441', '1', '17', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('442', '1', '18', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('443', '1', '20', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('444', '1', '21', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('445', '1', '22', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('446', '1', '23', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('447', '1', '24', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('448', '1', '25', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('449', '1', '26', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('450', '1', '27', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('451', '1', '28', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('452', '1', '29', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('453', '1', '30', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('454', '1', '31', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('455', '1', '32', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('456', '1', '33', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('457', '1', '34', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('458', '1', '35', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('459', '1', '36', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('460', '1', '37', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('461', '1', '38', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('462', '1', '39', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('463', '1', '40', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('464', '1', '41', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('465', '1', '42', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('466', '1', '43', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('467', '1', '44', '2026-08-22 21:37:40');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('468', '2', '6', '2026-08-22 21:38:35');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('469', '2', '21', '2026-08-22 21:38:35');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('470', '2', '12', '2026-08-22 21:38:35');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('471', '2', '1', '2026-08-22 21:38:35');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('472', '2', '23', '2026-08-22 21:38:35');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('473', '2', '11', '2026-08-22 21:38:35');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('474', '2', '25', '2026-08-22 21:38:35');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('475', '2', '26', '2026-08-22 21:38:35');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('476', '2', '5', '2026-08-22 21:38:35');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('477', '2', '24', '2026-08-22 21:38:35');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('478', '2', '14', '2026-08-22 21:38:35');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('479', '2', '8', '2026-08-22 21:38:35');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('480', '2', '29', '2026-08-22 21:38:35');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('481', '2', '30', '2026-08-22 21:38:35');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('482', '2', '13', '2026-08-22 21:38:35');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('483', '2', '3', '2026-08-22 21:38:35');
INSERT INTO `intramural_division_sports` (`id`, `division_id`, `sport_id`, `created_at`) VALUES ('484', '2', '17', '2026-08-22 21:38:35');

-- --------------------------------------------------------
-- Table: `intramural_divisions`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `intramural_divisions`;
CREATE TABLE `intramural_divisions` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_division_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `intramural_divisions` (`id`, `name`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('1', 'Collegiate', 'College Division', '1', '1', '2026-08-16 22:10:56', '2026-08-16 22:10:56');
INSERT INTO `intramural_divisions` (`id`, `name`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('2', 'High School', 'High School Division', '2', '1', '2026-08-16 22:11:16', '2026-08-16 22:11:16');

-- --------------------------------------------------------
-- Table: `intramural_event_coaches`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `intramural_event_coaches`;
CREATE TABLE `intramural_event_coaches` (
  `id` int(11) NOT NULL,
  `season_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `sport_id` int(11) NOT NULL,
  `coach_user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_team_sport_season_coach` (`team_id`,`sport_id`,`season_id`),
  KEY `season_id` (`season_id`),
  KEY `sport_id` (`sport_id`),
  KEY `coach_user_id` (`coach_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table: `intramural_event_managers`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `intramural_event_managers`;
CREATE TABLE `intramural_event_managers` (
  `id` int(11) NOT NULL,
  `season_id` int(11) NOT NULL,
  `sport_id` int(11) NOT NULL,
  `manager_user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sport_season_manager` (`sport_id`,`season_id`),
  KEY `season_id` (`season_id`),
  KEY `manager_user_id` (`manager_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('1', '1', '33', '34', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('2', '1', '18', '34', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('3', '1', '10', '34', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('4', '1', '36', '34', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('5', '1', '34', '34', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('6', '1', '37', '34', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('7', '1', '39', '34', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('8', '1', '40', '34', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('9', '1', '41', '34', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('10', '1', '42', '34', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('11', '1', '35', '34', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('12', '1', '38', '34', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('13', '1', '6', '31', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('14', '1', '21', '31', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('15', '1', '12', '36', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('16', '1', '22', '15', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('17', '1', '2', '15', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('18', '1', '1', '15', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('19', '1', '20', '15', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('20', '1', '23', '35', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('21', '1', '11', '35', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('22', '1', '31', '39', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('23', '1', '43', '39', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('25', '1', '25', '28', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('26', '1', '26', '28', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('27', '1', '5', '28', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('28', '1', '24', '28', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('29', '1', '14', '38', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('30', '1', '9', '37', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('31', '1', '27', '37', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('32', '1', '8', '33', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('33', '1', '29', '33', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('34', '1', '30', '33', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('35', '1', '32', '39', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('36', '1', '4', '32', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('37', '1', '13', '42', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('38', '1', '7', '29', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('39', '1', '28', '30', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('40', '1', '3', '25', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('41', '1', '17', '26', '2026-08-22 15:54:45', '2026-08-22 16:14:03');
INSERT INTO `intramural_event_managers` (`id`, `season_id`, `sport_id`, `manager_user_id`, `created_at`, `updated_at`) VALUES ('65', '1', '44', '39', '2026-08-22 16:14:03', '2026-08-22 16:14:03');

-- --------------------------------------------------------
-- Table: `intramural_event_ranks`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `intramural_event_ranks`;
CREATE TABLE `intramural_event_ranks` (
  `id` int(11) NOT NULL,
  `season_id` int(11) NOT NULL,
  `sport_id` int(11) NOT NULL,
  `division_id` int(11) NOT NULL DEFAULT 0,
  `team_id` int(11) NOT NULL,
  `place_rank` int(11) NOT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_event_rank_team` (`season_id`,`sport_id`,`division_id`,`team_id`),
  UNIQUE KEY `uq_event_rank_place` (`season_id`,`sport_id`,`division_id`,`place_rank`),
  KEY `sport_id` (`sport_id`),
  KEY `team_id` (`team_id`),
  KEY `created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table: `intramural_event_results_locks`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `intramural_event_results_locks`;
CREATE TABLE `intramural_event_results_locks` (
  `id` int(11) NOT NULL,
  `season_id` int(11) NOT NULL,
  `sport_id` int(11) NOT NULL,
  `locked_at` datetime DEFAULT NULL,
  `locked_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_event_results_lock` (`season_id`,`sport_id`),
  KEY `idx_event_results_lock_sport` (`sport_id`),
  KEY `locked_by` (`locked_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table: `intramural_event_team_positions`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `intramural_event_team_positions`;
CREATE TABLE `intramural_event_team_positions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `division_id` int(11) NOT NULL,
  `sport_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `position` tinyint(3) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_div_sport_position` (`division_id`,`sport_id`,`position`),
  UNIQUE KEY `uq_div_sport_team` (`division_id`,`sport_id`,`team_id`),
  KEY `sport_id` (`sport_id`),
  KEY `team_id` (`team_id`)
) ENGINE=InnoDB AUTO_INCREMENT=633 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('533', '1', '6', '4', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('534', '1', '6', '1', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('535', '1', '6', '2', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('536', '1', '6', '3', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('537', '1', '21', '4', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('538', '1', '21', '1', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('539', '1', '21', '2', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('540', '1', '21', '3', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('541', '1', '12', '3', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('542', '1', '12', '1', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('543', '1', '12', '2', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('544', '1', '12', '4', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('545', '1', '22', '3', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('546', '1', '22', '4', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('547', '1', '22', '2', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('548', '1', '22', '1', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('549', '1', '2', '3', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('550', '1', '2', '4', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('551', '1', '2', '2', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('552', '1', '2', '1', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('553', '1', '1', '3', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('554', '1', '1', '1', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('555', '1', '1', '2', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('556', '1', '1', '4', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('557', '1', '20', '3', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('558', '1', '20', '1', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('559', '1', '20', '2', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('560', '1', '20', '4', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('561', '1', '23', '3', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('562', '1', '23', '2', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('563', '1', '23', '4', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('564', '1', '23', '1', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('565', '1', '11', '3', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('566', '1', '11', '2', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('567', '1', '11', '4', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('568', '1', '11', '1', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('569', '1', '25', '3', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('570', '1', '25', '1', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('571', '1', '25', '2', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('572', '1', '25', '4', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('573', '1', '26', '3', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('574', '1', '26', '1', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('575', '1', '26', '2', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('576', '1', '26', '4', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('577', '1', '5', '4', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('578', '1', '5', '2', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('579', '1', '5', '3', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('580', '1', '5', '1', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('581', '1', '24', '4', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('582', '1', '24', '2', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('583', '1', '24', '3', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('584', '1', '24', '1', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('585', '1', '14', '3', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('586', '1', '14', '1', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('587', '1', '14', '2', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('588', '1', '14', '4', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('589', '1', '9', '4', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('590', '1', '9', '2', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('591', '1', '9', '3', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('592', '1', '9', '1', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('593', '1', '27', '4', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('594', '1', '27', '2', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('595', '1', '27', '3', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('596', '1', '27', '1', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('597', '1', '8', '2', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('598', '1', '8', '4', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('599', '1', '8', '3', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('600', '1', '8', '1', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('601', '1', '29', '2', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('602', '1', '29', '4', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('603', '1', '29', '3', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('604', '1', '29', '1', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('605', '1', '30', '2', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('606', '1', '30', '4', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('607', '1', '30', '3', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('608', '1', '30', '1', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('609', '1', '4', '2', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('610', '1', '4', '1', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('611', '1', '4', '3', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('612', '1', '4', '4', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('613', '1', '13', '3', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('614', '1', '13', '1', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('615', '1', '13', '2', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('616', '1', '13', '4', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('617', '1', '7', '3', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('618', '1', '7', '1', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('619', '1', '7', '2', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('620', '1', '7', '4', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('621', '1', '28', '3', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('622', '1', '28', '1', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('623', '1', '28', '2', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('624', '1', '28', '4', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('625', '1', '3', '3', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('626', '1', '3', '1', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('627', '1', '3', '2', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('628', '1', '3', '4', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('629', '1', '17', '3', '1', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('630', '1', '17', '1', '2', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('631', '1', '17', '2', '3', '2026-08-17 11:17:20', '2026-08-17 11:17:20');
INSERT INTO `intramural_event_team_positions` (`id`, `division_id`, `sport_id`, `team_id`, `position`, `created_at`, `updated_at`) VALUES ('632', '1', '17', '4', '4', '2026-08-17 11:17:20', '2026-08-17 11:17:20');

-- --------------------------------------------------------
-- Table: `intramural_event_tm_ranking`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `intramural_event_tm_ranking`;
CREATE TABLE `intramural_event_tm_ranking` (
  `id` int(11) NOT NULL,
  `season_id` int(11) NOT NULL,
  `sport_id` int(11) NOT NULL,
  `enabled_at` datetime DEFAULT NULL,
  `enabled_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_event_tm_ranking` (`season_id`,`sport_id`),
  KEY `idx_event_tm_ranking_sport` (`sport_id`),
  KEY `enabled_by` (`enabled_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `intramural_event_tm_ranking` (`id`, `season_id`, `sport_id`, `enabled_at`, `enabled_by`, `created_at`, `updated_at`) VALUES ('1', '1', '33', '2026-08-22 01:10:07', '1', '2026-08-22 16:10:07', '2026-08-22 16:10:07');
INSERT INTO `intramural_event_tm_ranking` (`id`, `season_id`, `sport_id`, `enabled_at`, `enabled_by`, `created_at`, `updated_at`) VALUES ('2', '1', '18', '2026-08-22 01:10:09', '1', '2026-08-22 16:10:09', '2026-08-22 16:10:09');
INSERT INTO `intramural_event_tm_ranking` (`id`, `season_id`, `sport_id`, `enabled_at`, `enabled_by`, `created_at`, `updated_at`) VALUES ('3', '1', '10', '2026-08-22 01:10:11', '1', '2026-08-22 16:10:11', '2026-08-22 16:10:11');
INSERT INTO `intramural_event_tm_ranking` (`id`, `season_id`, `sport_id`, `enabled_at`, `enabled_by`, `created_at`, `updated_at`) VALUES ('4', '1', '36', '2026-08-22 01:10:13', '1', '2026-08-22 16:10:13', '2026-08-22 16:10:13');
INSERT INTO `intramural_event_tm_ranking` (`id`, `season_id`, `sport_id`, `enabled_at`, `enabled_by`, `created_at`, `updated_at`) VALUES ('5', '1', '34', '2026-08-22 01:10:15', '1', '2026-08-22 16:10:15', '2026-08-22 16:10:15');
INSERT INTO `intramural_event_tm_ranking` (`id`, `season_id`, `sport_id`, `enabled_at`, `enabled_by`, `created_at`, `updated_at`) VALUES ('6', '1', '37', '2026-08-22 01:10:17', '1', '2026-08-22 16:10:17', '2026-08-22 16:10:17');
INSERT INTO `intramural_event_tm_ranking` (`id`, `season_id`, `sport_id`, `enabled_at`, `enabled_by`, `created_at`, `updated_at`) VALUES ('7', '1', '39', '2026-08-22 01:10:19', '1', '2026-08-22 16:10:19', '2026-08-22 16:10:19');
INSERT INTO `intramural_event_tm_ranking` (`id`, `season_id`, `sport_id`, `enabled_at`, `enabled_by`, `created_at`, `updated_at`) VALUES ('8', '1', '40', '2026-08-22 01:10:21', '1', '2026-08-22 16:10:21', '2026-08-22 16:10:21');
INSERT INTO `intramural_event_tm_ranking` (`id`, `season_id`, `sport_id`, `enabled_at`, `enabled_by`, `created_at`, `updated_at`) VALUES ('9', '1', '41', '2026-08-22 01:10:23', '1', '2026-08-22 16:10:23', '2026-08-22 16:10:23');
INSERT INTO `intramural_event_tm_ranking` (`id`, `season_id`, `sport_id`, `enabled_at`, `enabled_by`, `created_at`, `updated_at`) VALUES ('10', '1', '42', '2026-08-22 01:10:26', '1', '2026-08-22 16:10:26', '2026-08-22 16:10:26');
INSERT INTO `intramural_event_tm_ranking` (`id`, `season_id`, `sport_id`, `enabled_at`, `enabled_by`, `created_at`, `updated_at`) VALUES ('11', '1', '35', '2026-08-22 01:10:27', '1', '2026-08-22 16:10:27', '2026-08-22 16:10:27');
INSERT INTO `intramural_event_tm_ranking` (`id`, `season_id`, `sport_id`, `enabled_at`, `enabled_by`, `created_at`, `updated_at`) VALUES ('12', '1', '38', '2026-08-22 01:10:29', '1', '2026-08-22 16:10:29', '2026-08-22 16:10:29');
INSERT INTO `intramural_event_tm_ranking` (`id`, `season_id`, `sport_id`, `enabled_at`, `enabled_by`, `created_at`, `updated_at`) VALUES ('13', '1', '31', '2026-08-22 01:10:35', '1', '2026-08-22 16:10:35', '2026-08-22 16:10:35');
INSERT INTO `intramural_event_tm_ranking` (`id`, `season_id`, `sport_id`, `enabled_at`, `enabled_by`, `created_at`, `updated_at`) VALUES ('14', '1', '43', '2026-08-22 01:10:38', '1', '2026-08-22 16:10:38', '2026-08-22 16:10:38');
INSERT INTO `intramural_event_tm_ranking` (`id`, `season_id`, `sport_id`, `enabled_at`, `enabled_by`, `created_at`, `updated_at`) VALUES ('15', '1', '32', '2026-08-22 01:10:55', '1', '2026-08-22 16:10:55', '2026-08-22 16:10:55');

-- --------------------------------------------------------
-- Table: `intramural_matches`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `intramural_matches`;
CREATE TABLE `intramural_matches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `season_id` int(11) NOT NULL,
  `sport_id` int(11) NOT NULL,
  `division_id` int(11) DEFAULT NULL,
  `round_number` int(11) NOT NULL DEFAULT 1,
  `round_label` varchar(80) DEFAULT NULL,
  `match_order` int(11) NOT NULL DEFAULT 0,
  `is_generated` tinyint(1) NOT NULL DEFAULT 0,
  `team_a_id` int(11) DEFAULT NULL,
  `team_b_id` int(11) DEFAULT NULL,
  `scheduled_at` datetime DEFAULT NULL,
  `venue` varchar(150) DEFAULT NULL,
  `game_number` int(11) DEFAULT NULL,
  `referee_name` varchar(100) DEFAULT NULL,
  `status` enum('scheduled','ongoing','completed','cancelled','forfeit') NOT NULL DEFAULT 'scheduled',
  `score_a` int(11) DEFAULT NULL,
  `score_b` int(11) DEFAULT NULL,
  `winner_team_id` int(11) DEFAULT NULL,
  `forfeit_team_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `season_id` (`season_id`),
  KEY `sport_id` (`sport_id`),
  KEY `division_id` (`division_id`),
  KEY `team_a_id` (`team_a_id`),
  KEY `team_b_id` (`team_b_id`),
  KEY `winner_team_id` (`winner_team_id`),
  KEY `forfeit_team_id` (`forfeit_team_id`),
  KEY `created_by` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table: `intramural_point_schemes`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `intramural_point_schemes`;
CREATE TABLE `intramural_point_schemes` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `points_1` int(11) NOT NULL DEFAULT 10,
  `points_2` int(11) NOT NULL DEFAULT 7,
  `points_3` int(11) NOT NULL DEFAULT 5,
  `points_4` int(11) NOT NULL DEFAULT 3,
  `points_5` int(11) NOT NULL DEFAULT 2,
  `points_6` int(11) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `intramural_point_schemes` (`id`, `name`, `description`, `points_1`, `points_2`, `points_3`, `points_4`, `points_5`, `points_6`, `is_active`, `created_at`, `updated_at`) VALUES ('1', 'Major Team Sports', 'Basketball, Volleyball, Sepak Takraw, Esports, Baseball, Softball, Frisbee, Mass Power Dance', '10', '7', '5', '3', '2', '1', '1', '2026-08-16 22:02:18', '2026-08-16 22:02:18');
INSERT INTO `intramural_point_schemes` (`id`, `name`, `description`, `points_1`, `points_2`, `points_3`, `points_4`, `points_5`, `points_6`, `is_active`, `created_at`, `updated_at`) VALUES ('2', 'Racket & Dance Sports', 'Badminton, Table Tennis, Pickleball, Lawn Tennis, Dance Sports', '8', '6', '4', '3', '2', '1', '1', '2026-08-16 22:02:18', '2026-08-16 22:02:18');
INSERT INTO `intramural_point_schemes` (`id`, `name`, `description`, `points_1`, `points_2`, `points_3`, `points_4`, `points_5`, `points_6`, `is_active`, `created_at`, `updated_at`) VALUES ('3', 'Athletics & Chess', 'Athletics and Chess', '6', '5', '4', '3', '2', '1', '1', '2026-08-16 22:02:18', '2026-08-16 22:02:18');
INSERT INTO `intramural_point_schemes` (`id`, `name`, `description`, `points_1`, `points_2`, `points_3`, `points_4`, `points_5`, `points_6`, `is_active`, `created_at`, `updated_at`) VALUES ('4', 'Special Category', 'Special Category (Socio Power Dance)', '15', '12', '10', '7', '5', '3', '1', '2026-08-22 16:24:30', '2026-08-22 16:24:30');

-- --------------------------------------------------------
-- Table: `intramural_registrations`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `intramural_registrations`;
CREATE TABLE `intramural_registrations` (
  `id` int(11) NOT NULL,
  `season_id` int(11) NOT NULL,
  `athlete_id` int(11) NOT NULL,
  `sport_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `event_category` varchar(100) DEFAULT NULL,
  `jersey_number` varchar(10) DEFAULT NULL,
  `position` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_athlete_sport_season` (`athlete_id`,`sport_id`,`season_id`),
  KEY `season_id` (`season_id`),
  KEY `sport_id` (`sport_id`),
  KEY `team_id` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table: `intramural_seasons`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `intramural_seasons`;
CREATE TABLE `intramural_seasons` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `year_label` varchar(40) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_archived` tinyint(1) NOT NULL DEFAULT 0,
  `roster_locked` tinyint(1) NOT NULL DEFAULT 0,
  `roster_lock_date` date DEFAULT NULL,
  `roster_locked_at` datetime DEFAULT NULL,
  `roster_locked_by` int(11) DEFAULT NULL,
  `results_locked` tinyint(1) NOT NULL DEFAULT 0,
  `results_lock_date` date DEFAULT NULL,
  `results_locked_at` datetime DEFAULT NULL,
  `results_locked_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_season_year_label` (`year_label`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `intramural_seasons` (`id`, `name`, `year_label`, `start_date`, `end_date`, `description`, `is_active`, `is_archived`, `roster_locked`, `roster_lock_date`, `roster_locked_at`, `roster_locked_by`, `results_locked`, `results_lock_date`, `results_locked_at`, `results_locked_by`, `created_at`, `updated_at`) VALUES ('1', 'JHCSC Dumingag Campus PALARO', '2026-2027', '2026-08-24', '2026-08-26', 'Default intramurals season', '1', '0', '0', NULL, NULL, NULL, '0', NULL, NULL, NULL, '2026-08-16 22:02:18', '2026-08-22 15:08:46');

-- --------------------------------------------------------
-- Table: `intramural_sports`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `intramural_sports`;
CREATE TABLE `intramural_sports` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `category` enum('men','women','mixed') NOT NULL DEFAULT 'men',
  `players_per_event` int(11) DEFAULT NULL,
  `scoring_method` enum('points','sets','games','time') NOT NULL DEFAULT 'points',
  `rules` text DEFAULT NULL,
  `guidelines` text DEFAULT NULL,
  `schedule_notes` text DEFAULT NULL,
  `venue` varchar(150) DEFAULT NULL,
  `game_duration_minutes` int(11) NOT NULL DEFAULT 60,
  `tournament_format` enum('round_robin','single_elimination','single_elimination_consolation','modified_single_elimination_consolation','double_elimination','group_knockout','rank_first_to_last','team_play_sds','team_play_sds_consolation','custom') NOT NULL DEFAULT 'round_robin',
  `format_notes` text DEFAULT NULL,
  `win_points` int(11) NOT NULL DEFAULT 3,
  `draw_points` int(11) NOT NULL DEFAULT 1,
  `loss_points` int(11) NOT NULL DEFAULT 0,
  `point_scheme_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sport_name_category` (`name`,`category`),
  KEY `point_scheme_id` (`point_scheme_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('1', 'Basketball 5x5', '5-on-5 basketball', 'men', '15', 'points', '', NULL, '', 'JHCSC Basketball Court', '90', 'single_elimination_consolation', NULL, '3', '1', '0', '1', '2026-08-04 00:25:07', '2026-08-22 16:06:18');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('2', 'Basketball 3x3', '3-on-3 basketball', 'women', '4', 'points', '', NULL, '', 'JHCSC Basketball Court', '45', 'single_elimination_consolation', NULL, '3', '1', '0', '1', '2026-08-04 00:25:07', '2026-08-22 16:06:35');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('3', 'Volleyball', 'Indoor volleyball', 'men', '12', 'sets', '', NULL, '', 'JHCSC Campus (Volleyball Court)', '90', 'single_elimination_consolation', NULL, '3', '1', '0', '1', '2026-08-04 00:25:07', '2026-08-19 13:43:37');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('4', 'Sepak Takraw', 'Sepak takraw tournament', 'men', '12', 'sets', '', NULL, '', 'JHCSC Campus Takraw Court', '90', 'single_elimination_consolation', NULL, '3', '1', '0', '1', '2026-08-04 00:25:07', '2026-08-19 13:42:50');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('5', 'ESPORTS MLBB', 'Mobile Legends / Call of Duty Mobile', 'men', '6', 'games', '', NULL, '', 'SCS ComLab1', '60', 'single_elimination_consolation', NULL, '3', '1', '0', '1', '2026-08-04 00:25:07', '2026-08-14 05:03:57');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('6', 'Badminton', 'Badminton singles/doubles', 'men', '4', 'games', '', NULL, '', 'Caridad Covert Court', '45', 'team_play_sds_consolation', NULL, '3', '1', '0', '2', '2026-08-04 00:25:07', '2026-08-22 16:05:32');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('7', 'Table Tennis', 'Table tennis', 'men', '4', 'games', '', NULL, '', 'JHCSC Room - Table Tennis', '30', 'team_play_sds_consolation', NULL, '3', '1', '0', '2', '2026-08-04 00:25:07', '2026-08-19 13:54:18');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('8', 'Pickleball (Doubles)', 'Pickleball', 'men', '2', 'games', '', NULL, '', 'Mango Drive Pickledrive', '45', 'single_elimination_consolation', NULL, '3', '1', '0', '2', '2026-08-04 00:25:07', '2026-08-22 16:07:25');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('9', 'Lawn Tennis', 'Lawn tennis', 'men', '4', 'games', '', NULL, '', 'Dumingag Sports Complex Lawn Tennis Court', '45', 'team_play_sds_consolation', NULL, '3', '1', '0', '2', '2026-08-04 00:25:07', '2026-08-16 11:06:34');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('10', 'Athletics (200)', 'Track and field', 'men', '1', 'games', '', 'It is an individual competition representing their teams of men and women.\r\nIt consists of running events (100 & 200 meter dash, 400m, 800m run, 4x100m & 4x400m relays).', '', 'JHCSC Campus Oval', '180', 'custom', NULL, '3', '1', '0', '3', '2026-08-04 00:25:07', '2026-08-19 11:23:31');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('11', 'Chess', 'Chess', 'women', '4', 'games', '', NULL, '', 'JHCSC Library', '30', 'round_robin', NULL, '3', '1', '0', '3', '2026-08-04 00:25:07', '2026-08-14 05:57:42');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('12', 'Baseball', 'Baseball', 'men', '18', 'points', '', NULL, '', 'JHCSC Campus Baseball Diamond', '120', 'single_elimination_consolation', NULL, '3', '1', '0', '1', '2026-08-04 00:25:07', '2026-08-19 13:40:37');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('13', 'Softball', 'Softball', 'women', '18', 'points', '', NULL, '', 'JHCSC Campus Softball Diamond', '120', 'single_elimination_consolation', NULL, '3', '1', '0', '1', '2026-08-04 00:25:07', '2026-08-19 13:43:13');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('14', 'Frisbee', 'Ultimate frisbee', 'mixed', '15', 'points', '', NULL, '', 'JHCSC Campus Grounds', '60', 'single_elimination_consolation', NULL, '3', '1', '0', '1', '2026-08-04 00:25:07', '2026-08-14 05:04:24');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('17', 'Volleyball', '', 'women', '12', 'points', '', NULL, '', 'JHCSC Campus (Volleyball Court)', '90', 'single_elimination_consolation', NULL, '3', '1', '0', '1', '2026-08-04 02:23:38', '2026-08-19 15:06:56');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('18', 'Athletics (100m)', '', 'women', '1', 'games', '', 'It is an individual competition representing their teams of men and women.\r\nIt consists of running events (100 & 200 meter dash, 400m, 800m run, 4x100m & 4x400m relays).', '', 'JHCSC Campus Oval', '180', 'custom', NULL, '3', '1', '0', '3', '2026-08-14 01:32:41', '2026-08-19 11:23:24');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('20', 'Basketball 5x5', '5-on-5 basketball', 'women', '15', 'points', '', NULL, '', 'JHCSC Basketball Court', '90', 'single_elimination_consolation', NULL, '3', '1', '0', '1', '2026-08-14 01:46:18', '2026-08-22 16:06:50');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('21', 'Badminton', 'Badminton singles/doubles', 'women', '4', 'games', '', NULL, '', 'Caridad Covert Court', '45', 'team_play_sds_consolation', NULL, '3', '1', '0', '2', '2026-08-14 01:47:04', '2026-08-22 16:05:41');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('22', 'Basketball 3x3', '3-on-3 basketball', 'men', '4', 'points', '', NULL, '', 'JHCSC Basketball Court', '45', 'single_elimination_consolation', NULL, '3', '1', '0', '1', '2026-08-14 01:48:14', '2026-08-22 16:06:04');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('23', 'Chess', 'Chess', 'men', '4', 'games', '', NULL, '', 'JHCSC Library', '30', 'round_robin', NULL, '3', '1', '0', '3', '2026-08-14 01:48:50', '2026-08-14 05:57:42');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('24', 'ESPORTS MLBB', 'Mobile Legends / Call of Duty Mobile', 'women', '6', 'games', '', NULL, '', 'SCS ComLab1', '60', 'single_elimination_consolation', NULL, '3', '1', '0', '1', '2026-08-14 01:50:42', '2026-08-14 05:04:09');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('25', 'ESPORTS CODM', 'Mobile Legends / Call of Duty Mobile', 'men', '6', 'games', '', NULL, '', 'SCS ComLab1', '60', 'single_elimination_consolation', NULL, '3', '1', '0', '1', '2026-08-14 01:50:57', '2026-08-14 05:03:36');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('26', 'ESPORTS CODM', 'Mobile Legends / Call of Duty Mobile', 'women', '6', 'games', '', NULL, '', 'SCS ComLab1', '60', 'single_elimination_consolation', NULL, '3', '1', '0', '1', '2026-08-14 01:51:10', '2026-08-14 05:03:44');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('27', 'Lawn Tennis', 'Lawn tennis', 'women', '4', 'games', '', NULL, '', 'Dumingag Sports Complex Lawn Tennis Court', '45', 'team_play_sds_consolation', NULL, '3', '1', '0', '2', '2026-08-14 01:51:41', '2026-08-16 11:06:55');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('28', 'Table Tennis', 'Table tennis', 'women', '4', 'games', '', NULL, '', 'JHCSC Room - Table Tennis', '30', 'team_play_sds_consolation', NULL, '3', '1', '0', '2', '2026-08-14 01:52:33', '2026-08-19 13:54:27');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('29', 'Pickleball (Doubles)', 'Pickleball', 'women', '2', 'games', '', NULL, '', 'Mango Drive Pickledrive', '45', 'single_elimination_consolation', NULL, '3', '1', '0', '2', '2026-08-14 01:54:20', '2026-08-22 16:07:37');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('30', 'Pickleball (Doubles)', 'Pickleball', 'mixed', '2', 'games', '', NULL, '', 'Mango Drive Pickledrive', '45', 'single_elimination_consolation', NULL, '3', '1', '0', '2', '2026-08-14 01:54:33', '2026-08-22 16:07:56');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('31', 'Dance Sports (Latin)', '', 'mixed', '2', 'points', '', NULL, '', 'JHCSC Function Hall', '60', 'custom', NULL, '3', '1', '0', '2', '2026-08-15 00:17:25', '2026-08-15 00:25:04');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('32', 'Powerdance', '', 'mixed', '50', 'points', '', NULL, '', 'JHCSC Campus Grounds', '60', 'custom', NULL, '3', '1', '0', '4', '2026-08-15 02:17:40', '2026-08-22 16:24:38');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('33', 'Athletics (100m)', 'Track and field', 'men', '1', 'games', '', 'It is an individual competition representing their teams of men and women.\r\nIt consists of running events (100 & 200 meter dash, 400m, 800m run, 4x100m & 4x400m relays).', '', 'JHCSC Campus Oval', '180', 'custom', NULL, '3', '1', '0', '3', '2026-08-16 10:57:29', '2026-08-19 11:23:12');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('34', 'Athletics (400)', 'Track and field', 'men', '1', 'games', '', 'It is an individual competition representing their teams of men and women.\r\nIt consists of running events (100 & 200 meter dash, 400m, 800m run, 4x100m & 4x400m relays).', '', 'JHCSC Campus Oval', '180', 'custom', NULL, '3', '1', '0', '3', '2026-08-16 10:58:34', '2026-08-19 11:23:59');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('35', 'Athletics (800)', 'Track and field', 'men', '1', 'games', '', 'It is an individual competition representing their teams of men and women.\r\nIt consists of running events (100 & 200 meter dash, 400m, 800m run, 4x100m & 4x400m relays).', '', 'JHCSC Campus Oval', '180', 'custom', NULL, '3', '1', '0', '3', '2026-08-16 10:58:51', '2026-08-19 11:25:10');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('36', 'Athletics (200)', 'Track and field', 'women', '1', 'games', '', 'It is an individual competition representing their teams of men and women.\r\nIt consists of running events (100 & 200 meter dash, 400m, 800m run, 4x100m & 4x400m relays).', '', 'JHCSC Campus Oval', '180', 'custom', NULL, '3', '1', '0', '3', '2026-08-16 11:00:51', '2026-08-19 11:23:50');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('37', 'Athletics (400)', 'Track and field', 'women', '1', 'games', '', 'It is an individual competition representing their teams of men and women.\r\nIt consists of running events (100 & 200 meter dash, 400m, 800m run, 4x100m & 4x400m relays).', '', 'JHCSC Campus Oval', '180', 'custom', NULL, '3', '1', '0', '3', '2026-08-16 11:01:01', '2026-08-19 11:24:09');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('38', 'Athletics (800)', 'Track and field', 'women', '1', 'games', '', 'It is an individual competition representing their teams of men and women.\r\nIt consists of running events (100 & 200 meter dash, 400m, 800m run, 4x100m & 4x400m relays).', '', 'JHCSC Campus Oval', '180', 'custom', NULL, '3', '1', '0', '3', '2026-08-16 11:01:30', '2026-08-19 11:25:19');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('39', 'Athletics (4x100m)', 'Track and field', 'men', '4', 'games', '', 'It is an individual competition representing their teams of men and women.\r\nIt consists of running events (100 & 200 meter dash, 400m, 800m run, 4x100m & 4x400m relays).', '', 'JHCSC Campus Oval', '180', 'custom', NULL, '3', '1', '0', NULL, '2026-08-16 11:02:05', '2026-08-19 11:24:30');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('40', 'Athletics (4x100m)', 'Track and field', 'women', '4', 'games', '', 'It is an individual competition representing their teams of men and women.\r\nIt consists of running events (100 & 200 meter dash, 400m, 800m run, 4x100m & 4x400m relays).', '', 'JHCSC Campus Oval', '180', 'custom', NULL, '3', '1', '0', NULL, '2026-08-16 11:02:21', '2026-08-19 11:24:42');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('41', 'Athletics (4x400m)', 'Track and field', 'men', '4', 'games', '', 'It is an individual competition representing their teams of men and women.\r\nIt consists of running events (100 & 200 meter dash, 400m, 800m run, 4x100m & 4x400m relays).', '', 'JHCSC Campus Oval', '180', 'custom', NULL, '3', '1', '0', NULL, '2026-08-16 11:03:08', '2026-08-19 11:24:51');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('42', 'Athletics (4x400m)', 'Track and field', 'women', '4', 'games', '', 'It is an individual competition representing their teams of men and women.\r\nIt consists of running events (100 & 200 meter dash, 400m, 800m run, 4x100m & 4x400m relays).', '', 'JHCSC Campus Oval', '180', 'custom', NULL, '3', '1', '0', NULL, '2026-08-16 11:03:18', '2026-08-19 11:25:00');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('43', 'Dance Sports (Modern Standard)', '', 'mixed', '2', 'points', '', NULL, '', 'JHCSC Function Hall', '60', 'custom', NULL, '3', '1', '0', '2', '2026-08-16 11:05:00', '2026-08-16 11:05:00');
INSERT INTO `intramural_sports` (`id`, `name`, `description`, `category`, `players_per_event`, `scoring_method`, `rules`, `guidelines`, `schedule_notes`, `venue`, `game_duration_minutes`, `tournament_format`, `format_notes`, `win_points`, `draw_points`, `loss_points`, `point_scheme_id`, `created_at`, `updated_at`) VALUES ('44', 'Dance Sports (Third Kind)', '', 'mixed', '2', 'points', '', NULL, '', 'JHCSC Function Hall', '60', 'custom', NULL, '3', '1', '0', '2', '2026-08-22 16:13:36', '2026-08-22 16:13:36');

-- --------------------------------------------------------
-- Table: `intramural_teams`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `intramural_teams`;
CREATE TABLE `intramural_teams` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `short_name` varchar(30) DEFAULT NULL,
  `color` varchar(20) DEFAULT '#1a5276',
  `logo` varchar(255) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `division_id` int(11) DEFAULT NULL,
  `coach_name` varchar(100) DEFAULT NULL,
  `unit_manager_id` int(11) DEFAULT NULL,
  `coach_user_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_team_name` (`name`),
  KEY `division_id` (`division_id`),
  KEY `fk_team_unit_manager` (`unit_manager_id`),
  KEY `fk_team_coach_user` (`coach_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `intramural_teams` (`id`, `name`, `short_name`, `color`, `logo`, `department`, `division_id`, `coach_name`, `unit_manager_id`, `coach_user_id`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('1', 'STE Phoenix', 'PHOENIX', '#0782cf', NULL, 'School of Teacher Education', '1', '', '24', NULL, '', '1', '2026-08-04 00:25:07', '2026-08-22 21:37:40');
INSERT INTO `intramural_teams` (`id`, `name`, `short_name`, `color`, `logo`, `department`, `division_id`, `coach_name`, `unit_manager_id`, `coach_user_id`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('2', 'SCS Firefox', 'FIREFOX', '#c0392b', NULL, 'School of Computing Studies', '1', '', '23', NULL, '', '1', '2026-08-04 00:25:07', '2026-08-22 21:37:40');
INSERT INTO `intramural_teams` (`id`, `name`, `short_name`, `color`, `logo`, `department`, `division_id`, `coach_name`, `unit_manager_id`, `coach_user_id`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('3', 'SAFES Bulls', 'BULLS', '#1e8449', NULL, 'School of Agriculture, Fisheries and Environmental Studies', '1', '', '22', NULL, '', '1', '2026-08-04 00:25:07', '2026-08-22 21:37:40');
INSERT INTO `intramural_teams` (`id`, `name`, `short_name`, `color`, `logo`, `department`, `division_id`, `coach_name`, `unit_manager_id`, `coach_user_id`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('4', 'SOCJE Dragons', 'DRAGONS', '#e1900e', NULL, 'School of Criminal Justice Education', '1', '', '21', NULL, '', '1', '2026-08-04 00:25:07', '2026-08-22 21:37:40');
INSERT INTO `intramural_teams` (`id`, `name`, `short_name`, `color`, `logo`, `department`, `division_id`, `coach_name`, `unit_manager_id`, `coach_user_id`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('5', 'HS Team A (ZEPHRYNX)', 'HS-A', '#e942f5', NULL, 'High School', '2', '', '40', NULL, '', '1', '2026-08-16 07:39:15', '2026-08-22 21:38:35');
INSERT INTO `intramural_teams` (`id`, `name`, `short_name`, `color`, `logo`, `department`, `division_id`, `coach_name`, `unit_manager_id`, `coach_user_id`, `description`, `is_active`, `created_at`, `updated_at`) VALUES ('6', 'HS Team B (AURELIAN)', 'HS-B', '#3b09f1', NULL, 'High School', '2', '', '41', NULL, '', '1', '2026-08-16 07:40:18', '2026-08-22 21:38:35');

-- --------------------------------------------------------
-- Table: `login_history`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `login_history`;
CREATE TABLE `login_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `status` enum('success','failed') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table: `maintenance_schedule`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `maintenance_schedule`;
CREATE TABLE `maintenance_schedule` (
  `id` int(11) NOT NULL,
  `equipment_id` int(11) NOT NULL,
  `scheduled_date` date NOT NULL,
  `maintenance_type` enum('routine','repair','inspection','cleaning') NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('scheduled','in_progress','completed','cancelled') NOT NULL DEFAULT 'scheduled',
  `completed_at` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `equipment_id` (`equipment_id`),
  KEY `created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table: `notifications`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','success','warning','danger') NOT NULL DEFAULT 'info',
  `link` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- --------------------------------------------------------
-- Table: `system_settings`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text NOT NULL,
  `setting_type` enum('string','integer','boolean','json') NOT NULL DEFAULT 'string',
  `description` text DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`),
  KEY `updated_by` (`updated_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `description`, `updated_by`, `updated_at`) VALUES ('1', 'max_borrow_days', '14', 'integer', 'Maximum number of days for borrowing', NULL, '2026-08-16 22:02:18');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `description`, `updated_by`, `updated_at`) VALUES ('2', 'default_borrow_days', '7', 'integer', 'Default borrowing period in days', NULL, '2026-08-16 22:02:18');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `description`, `updated_by`, `updated_at`) VALUES ('3', 'max_borrow_items', '5', 'integer', 'Maximum items a user can borrow at once', NULL, '2026-08-16 22:02:18');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `description`, `updated_by`, `updated_at`) VALUES ('4', 'low_stock_threshold', '3', 'integer', 'Alert when stock falls below this number', NULL, '2026-08-16 22:02:18');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `description`, `updated_by`, `updated_at`) VALUES ('5', 'require_approval', '1', 'boolean', 'Require coordinator approval for borrowing requests', NULL, '2026-08-16 22:02:18');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `description`, `updated_by`, `updated_at`) VALUES ('6', 'notification_email', '1', 'boolean', 'Enable email notifications', NULL, '2026-08-16 22:02:18');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `description`, `updated_by`, `updated_at`) VALUES ('7', 'overdue_reminder_days', '1', 'integer', 'Days before due date to send reminder', NULL, '2026-08-16 22:02:18');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `description`, `updated_by`, `updated_at`) VALUES ('8', 'campus_name', 'J.H. Cerilles State College', 'string', 'Campus name', NULL, '2026-08-16 22:02:18');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `description`, `updated_by`, `updated_at`) VALUES ('9', 'borrowing_policy', 'All borrowed equipment must be returned in the same condition. Late returns may result in borrowing privileges being suspended.', 'string', 'Borrowing policy text', NULL, '2026-08-16 22:02:18');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `description`, `updated_by`, `updated_at`) VALUES ('10', 'theme_preset', 'forest_green', 'string', 'Active theme preset', '1', '2026-08-17 05:59:39');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `description`, `updated_by`, `updated_at`) VALUES ('11', 'theme_primary', '#1e5631', 'string', 'Custom primary color', '1', '2026-08-17 05:59:39');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `description`, `updated_by`, `updated_at`) VALUES ('12', 'theme_secondary', '#27ae60', 'string', 'Custom secondary color', '1', '2026-08-17 05:59:39');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `description`, `updated_by`, `updated_at`) VALUES ('13', 'theme_accent', '#f1c40f', 'string', 'Custom accent color', '1', '2026-08-17 05:59:39');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `description`, `updated_by`, `updated_at`) VALUES ('14', 'theme_body_bg', '#f0f7f2', 'string', 'Custom body background', '1', '2026-08-17 05:59:39');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `description`, `updated_by`, `updated_at`) VALUES ('15', 'theme_card_bg', '#ffffff', 'string', 'Custom card background', '1', '2026-08-17 05:59:39');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `description`, `updated_by`, `updated_at`) VALUES ('16', 'theme_text', '#1a3326', 'string', 'Custom text color', '1', '2026-08-17 05:59:39');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `description`, `updated_by`, `updated_at`) VALUES ('17', 'theme_login_gradient', 'linear-gradient(135deg, #1e5631 0%, #27ae60 50%, #2ecc71 100%)', 'string', 'Login page gradient', '1', '2026-08-17 05:59:39');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `description`, `updated_by`, `updated_at`) VALUES ('18', 'working_committees_seeded', '1', 'boolean', 'Working committee document already imported', NULL, '2026-08-17 23:53:40');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `description`, `updated_by`, `updated_at`) VALUES ('19', 'working_committees_socio_seeded', '1', 'boolean', 'Socio-cultural working committees already imported', NULL, '2026-08-17 23:53:40');
INSERT INTO `system_settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `description`, `updated_by`, `updated_at`) VALUES ('20', 'working_committees_overall_seeded', '1', 'boolean', 'Overall working committees already imported', NULL, '2026-08-17 23:53:40');

-- --------------------------------------------------------
-- Table: `users`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `password_plain` varchar(255) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `student_id` varchar(20) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `role` enum('admin','coordinator','staff','unit_manager','coach','tabulator','secretariat','publication','student') NOT NULL DEFAULT 'student',
  `team_id` int(11) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `fk_users_team` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('1', 'admin', 'admin@jhcsc.edu.ph', '$2y$10$A7qSNA6wXopqKn1I5ecTV.qLZyKnG1xAHq1bO3gYbVkpLXJ3aX0FO', 'stevenimba', 'System', 'Administrator', NULL, NULL, NULL, 'admin', NULL, NULL, '1', '2026-08-04 00:25:03', '2026-08-17 11:24:09');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('2', 'coordinator', 'coordinator@jhcsc.edu.ph', '$2y$10$NKHgE07F2acQPzEmaEB9FeaBB/2Y2e/acncWDo0U19wF7F7u3KK.y', 'admin123', 'Sports', 'Coordinator', NULL, NULL, NULL, 'coordinator', NULL, NULL, '1', '2026-08-04 00:25:03', '2026-08-04 01:38:17');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('3', 'staff', 'staff@jhcsc.edu.ph', '$2y$10$NKHgE07F2acQPzEmaEB9FeaBB/2Y2e/acncWDo0U19wF7F7u3KK.y', 'admin123', 'Sports', 'Staff', NULL, NULL, NULL, 'staff', NULL, NULL, '1', '2026-08-04 00:25:03', '2026-08-04 01:38:17');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('4', 'student', 'student@jhcsc.edu.ph', '$2y$10$NKHgE07F2acQPzEmaEB9FeaBB/2Y2e/acncWDo0U19wF7F7u3KK.y', 'admin123', 'Juan', 'Dela Cruz', NULL, NULL, NULL, 'student', NULL, NULL, '1', '2026-08-04 00:25:03', '2026-08-04 01:38:17');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('15', 'ambalong', 'ambalong@gmail.com', '$2y$10$pdQkq8No/.09IaFJgjzgpO/dy/EwZ16Mz8HJj0hf6KDhAiw26rlxa', 'admin123', 'Nicaster Ambalong', '(Basketball)', NULL, NULL, NULL, 'tabulator', NULL, NULL, '1', '2026-08-14 00:27:44', '2026-08-16 11:27:55');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('16', 'secretariat', 'secretariat@jhcsc.edu.ph', '$2y$10$1BaSuX/FXv5mem09B3WPl.QTqQfKdwWXCJtBqhwSHzH4x8B3mlCha', 'admin123', 'Intramurals', 'Secretariat', NULL, 'Sports Unit', NULL, 'secretariat', NULL, NULL, '1', '2026-08-14 00:42:49', '2026-08-14 00:42:49');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('20', 'publication', 'publication@jhcsc.edu.ph', '$2y$10$pnNFU722N/ItXFJBhJYRBOMtFFHw6iyxLK6o6yMXRnlcddRa4jOc.', 'admin123', 'Intramurals', 'Publication', NULL, 'Sports Unit', NULL, 'publication', NULL, NULL, '1', '2026-08-16 00:38:51', '2026-08-16 00:38:51');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('21', 'um_socje', 'socje@gmail.om', '$2y$10$6jue1JZzd/l.bdZ1f9DwCu4fljuNeVQ9wDxmokZNLdHlAe2qYxNQW', 'admin123', 'Unit Manager', 'SOCJE', NULL, NULL, NULL, 'unit_manager', '4', NULL, '1', '2026-08-16 00:42:36', '2026-08-16 11:17:33');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('22', 'um_safes', 'safes@gmail.com', '$2y$10$aSIYY1hBMB514yssyJoadelU50OaaDRZ86uFMsOorAse9jegC/QKO', 'admin123', 'Unit Manager', 'SAFES', NULL, NULL, NULL, 'unit_manager', '3', NULL, '1', '2026-08-16 00:43:12', '2026-08-16 11:17:15');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('23', 'um_scs', 'scs@gmail.com', '$2y$10$K2U9r4PZZaSf23McK2k86ubuOnSAhZIMbFa16Hcr.yRnGI.PlvdT6', 'admin123', 'Unit Manager', 'SCS', NULL, NULL, NULL, 'unit_manager', '2', NULL, '1', '2026-08-16 11:15:56', '2026-08-16 11:16:57');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('24', 'um_ste', 'ste@gmail.com', '$2y$10$ImCXLmf7bRhuhHZYH/0GlO5hJt89iWtbeKmlIXRtyolJCJIBA4X/y', 'admin123', 'Unit Manager', 'STE', NULL, NULL, NULL, 'unit_manager', '1', NULL, '1', '2026-08-16 11:16:39', '2026-08-16 11:16:39');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('25', 'matos', 'matos@gmail.com', '$2y$10$BrEl/2RA6GFrytsb9lN3Hu7Z5IRXIj8XQ5ARnTVbDvz9PFUh5tcCS', 'admin123', 'Zenon A. Matos, Jr.', '(Volleyball Men)', NULL, NULL, NULL, 'tabulator', NULL, NULL, '1', '2026-08-16 11:27:41', '2026-08-16 11:27:41');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('26', 'bustamante', 'bustamante@gmail.com', '$2y$10$toSsU.hrQVmliI.uXLzJ3OfsBOrstx6Gfp6N5Cun6wJ3LtS9vuVB2', 'admin123', 'Ronilo S. Bustamante', '(Volleyball Women)', NULL, NULL, NULL, 'tabulator', NULL, NULL, '1', '2026-08-16 11:29:39', '2026-08-16 11:29:39');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('28', 'barluado', 'barluado@gmail.com', '$2y$10$r7WK4c4Y5h9ktTQ7jvAnKukpb1/6YtfePZpeCf8RMnOnDjHa2Asui', 'admin123', 'Rob Kellean B. Barluado', '(ESports)', NULL, NULL, NULL, 'tabulator', NULL, NULL, '1', '2026-08-16 11:32:17', '2026-08-16 11:32:17');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('29', 'candia', 'candia@gmail.com', '$2y$10$8OvDudHg/rZ2iGVHFK8arOuc3JAoPLmSl6jx7.p41dB8RedMWjgGO', 'admin123', 'Danny Lou C. Candia', '(Table Tennis Men)', NULL, NULL, NULL, 'tabulator', NULL, NULL, '1', '2026-08-16 11:34:05', '2026-08-16 11:34:05');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('30', 'elardo', 'elardo@gmail.com', '$2y$10$Trbs2LCUEwfoSafE8U7XVeEqAp3hAoUxjEKQtLGSLdrgevoG5RVPK', 'admin123', 'Helen Grace L. Elardo', '(Table Tennis Women)', NULL, NULL, NULL, 'tabulator', NULL, NULL, '1', '2026-08-16 11:35:23', '2026-08-16 11:35:23');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('31', 'maryjuliet', 'maryjuliet@gmail.com', '$2y$10$iTnTudQPU2Nv4cQpO6X9ZeSp8XgcBaerpoB11v1i.puNEkypuC706', '12345678', 'Mary Juliet Doño', '(Badminton M/W)', NULL, NULL, NULL, 'tabulator', NULL, NULL, '1', '2026-08-16 11:36:55', '2026-08-17 12:28:28');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('32', 'canencia', 'canencia@gmail.com', '$2y$10$taYHynoZoyi4hwRS.SMAKOUAzZoLXlyTQE3r7kU0phdsQ/94Ek3X2', 'admin123', 'Niñobel Canencia', '(Sepak Takraw)', NULL, NULL, NULL, 'tabulator', NULL, NULL, '1', '2026-08-16 11:37:44', '2026-08-22 15:51:31');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('33', 'chatto', 'chatto@gmail.com', '$2y$10$NTQu7VAmOnCaQY34tK/m2.6sxFxM.7nFL23C5OmHxnNXgm0CjBwTO', 'admin123', 'Vincent John Chatto', '(Pickleball)', NULL, NULL, NULL, 'tabulator', NULL, NULL, '1', '2026-08-16 11:38:47', '2026-08-16 11:38:47');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('34', 'bacalso', 'bacalso@gmail.com', '$2y$10$a1gs35WCI.5WcO/iInIJrOhgvB5In7CxzXKunvvkFjMNlQ9yGEf46', 'admin123', 'Jezreel G. Bacalso', '(Athletics M/W)', NULL, NULL, NULL, 'tabulator', NULL, NULL, '1', '2026-08-16 11:39:43', '2026-08-16 11:39:43');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('35', 'bascon', 'bascon@gmail.com', '$2y$10$IkmnBtK.D4HcOuIPHlFwU.E.fwtpr6k/PsqJqhNfUXhrI0v9vw3i2', 'admin123', 'Carlo Giovanni D. Bascon', '(Chess M/W)', NULL, NULL, NULL, 'tabulator', NULL, NULL, '1', '2026-08-16 11:41:00', '2026-08-16 11:41:00');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('36', 'paquibo', 'paquibo@gmail.com', '$2y$10$R92Jbl9BoMv1rXItTMRYvegvb3pHMq2bTEyvwFjN1.LQu2YfeBtq6', 'admin123', 'Grape A. Paquibo', '(Baseball)', NULL, NULL, NULL, 'tabulator', NULL, NULL, '1', '2026-08-16 11:41:46', '2026-08-16 11:41:46');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('37', 'batucan', 'batucan@gmail.com', '$2y$10$VqtWR4ZOG7SuD5rD/ktcteGgSgh/o8Cm7oCjV8ASF0CvNZblHa8Pm', 'admin123', 'Hannah Batucan', '(Lawn Tennis)', NULL, NULL, NULL, 'tabulator', NULL, NULL, '1', '2026-08-16 11:42:30', '2026-08-22 15:51:05');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('38', 'lauron', 'lauron@gmail.com', '$2y$10$oWmZefz5AQeEfVski8zjxuHiKZI5v4IFsy7k7t8y0JPGgfUHZHsv.', 'admin123', 'Eric Lauron', '(Frisbee)', NULL, NULL, NULL, 'tabulator', NULL, NULL, '1', '2026-08-16 11:44:25', '2026-08-16 11:44:25');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('39', 'cabigas', 'cabigas@gmail.com', '$2y$10$nc9bHM2pge9nK5d7kuKX8ee9py7.vQEIxjtWUceQGUQjpVVjZuody', 'admin123', 'Marjorey Cabigas', '(Socio Dances)', NULL, NULL, NULL, 'tabulator', NULL, NULL, '1', '2026-08-16 11:49:09', '2026-08-16 11:49:09');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('40', 'um_hsa', 'hsa@gmail.com', '$2y$10$EgXOA397.5zs/cm0RhkBw.iMCYqZ8ecueLuWdPi67MhfyOQhez/ZO', 'admin123', 'High School', 'Team A', NULL, NULL, NULL, 'unit_manager', '5', NULL, '1', '2026-08-19 13:27:39', '2026-08-19 13:27:39');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('41', 'um_hsb', 'hsb@gmail.com', '$2y$10$fY2e1j20cdMVvcV6.bfcsejSs7FCiaxAyce0XTEA2xZe2lE0mB1mW', 'admin123', 'High School', 'Team B', NULL, NULL, NULL, 'unit_manager', '6', NULL, '1', '2026-08-19 13:28:11', '2026-08-19 13:28:11');
INSERT INTO `users` (`id`, `username`, `email`, `password`, `password_plain`, `first_name`, `last_name`, `student_id`, `department`, `phone`, `role`, `team_id`, `avatar`, `is_active`, `created_at`, `updated_at`) VALUES ('42', 'mori', 'mori@gmail.com', '$2y$10$etxcUIByFOnRYINIpV8AX.JQ/Czmj7y8K3ECqSc5OROFUUufXuRr2', 'admin123', 'Allen Day Mori', '(Softball)', NULL, NULL, NULL, 'tabulator', NULL, NULL, '1', '2026-08-22 15:52:23', '2026-08-22 15:52:23');

-- --------------------------------------------------------
-- Table: `working_committee_members`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `working_committee_members`;
CREATE TABLE `working_committee_members` (
  `id` int(11) NOT NULL,
  `committee_id` int(11) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `position_title` varchar(120) DEFAULT NULL,
  `organization` varchar(150) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_wc_member_committee` (`committee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('1', '1', 'TBD (Paid Referee)', 'Chief Referee', NULL, '1', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('2', '1', 'Zenon A. Matos, Jr.', 'Asst. Referee', NULL, '2', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:48');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('3', '1', 'Melesa S. Galvez', 'Scorer', NULL, '3', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('4', '1', 'Lovely L. Daluag-Gorre', 'Linesman', NULL, '4', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('5', '1', 'Gloryfe E. Almodal', 'Linesman', NULL, '5', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('6', '2', 'TBD (Paid Referee)', 'Chief Referee', NULL, '1', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('7', '2', 'Ronilo S. Bustamante', 'Asst. Referee', NULL, '2', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('8', '2', 'Lanilyn P. Bustamante', 'Scorer', NULL, '3', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('9', '2', 'Jennifer T. Bestudio', 'Linesman', NULL, '4', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('10', '2', 'Jessie E. Tormis-Idias', 'Linesman', NULL, '5', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('11', '3', 'Ninobel G. Canencia', 'Chief Referee', NULL, '1', '1', '2026-08-17 22:25:08', '2026-08-18 08:23:10');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('12', '3', 'Alma P. Sumbe', 'Scorer', NULL, '2', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('13', '3', 'Myrna P. Perigo', 'Member', NULL, '3', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('14', '4', 'Nelson V. Idias', 'Venue Manager', NULL, '1', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('15', '4', 'Rob Kellean B. Barluado', 'Tournament Manager', NULL, '2', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('16', '4', 'Flora Mae S. Cogalito', 'Member', NULL, '3', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('17', '4', 'Jeward C. Dago-oc', 'Member', NULL, '4', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('18', '4', 'Ronette Chris D. Bilbao', 'Member', NULL, '5', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('19', '5', 'Danny Lou C. Candia', 'Chief Referee', NULL, '1', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('20', '5', 'Queeny Rose C. Baluyos', 'Member', NULL, '2', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('21', '5', 'Rhea T. Mandaya', 'Scorer', NULL, '3', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('22', '6', 'Helen Grace L. Elardo', 'Chief Referee', NULL, '1', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('23', '6', 'Krichelle O. Villarubia', 'Scorer', NULL, '2', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('24', '7', 'Mary Juliet Doño', 'Chief Referee', NULL, '1', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('25', '7', 'Mariza S. Balatero', 'Scorer', NULL, '2', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('26', '7', 'Rhivee Mae H. Conol', 'Member', NULL, '3', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('27', '7', 'Lorejean E. Pangasian', 'Member', NULL, '4', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('28', '7', 'Myrel Shane C. Abayon', 'Member', NULL, '5', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('29', '7', 'Lara Jane A. Espina', 'Member', NULL, '6', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('30', '8', 'Hanna Batucan', 'Chief Referee', NULL, '1', '1', '2026-08-17 22:25:08', '2026-08-18 08:20:09');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('31', '8', 'Joyce Capangpangan', 'Scorer', NULL, '2', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('32', '8', 'Irene B. Labadisos', 'Member', NULL, '3', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('33', '8', 'Michelle M. Mangubat', 'Member', NULL, '4', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('34', '9', 'Vincent John Chatto', 'Chief Referee', NULL, '1', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('35', '9', 'Prexy Jeede B. Tangalin', 'Scorer', NULL, '2', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('36', '9', 'Romafe P. Matos', 'Member', NULL, '3', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('37', '9', 'Mayflor E. Gose', 'Member', NULL, '4', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('38', '9', 'Dirb Boy Sebrero', 'Member', NULL, '5', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('39', '10', 'Jezreel G. Bacalso', 'Chief Referee', NULL, '1', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('40', '10', 'Judith Bastasa', 'Timekeeper', NULL, '2', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('41', '10', 'April N. Libot', 'Member', NULL, '3', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('42', '10', 'Junry M. Mangubat', 'Member', NULL, '4', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('43', '10', 'Mariel Jun B. Sanchez', 'Member', NULL, '5', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('44', '10', 'Jessa Mae A. Gomez', 'Member', NULL, '6', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('45', '10', 'Marielou C. Lasmarias', 'Member', NULL, '7', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('46', '10', 'DRRMO', 'Member', NULL, '8', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('47', '10', 'Clinic', 'Member', NULL, '9', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('48', '11', 'Carlo Giovanni D. Bascon', 'Arbiter', NULL, '1', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('49', '11', 'Paulino R. Tagaylo', 'Arbiter', NULL, '2', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('50', '11', 'Allan Z. Caw-it', 'Arbiter', NULL, '3', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('51', '12', 'TBD (Paid Umpire)', 'Chief Umpire', NULL, '1', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('52', '12', 'Lyka A. Cuevas', 'Scorer', NULL, '2', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('53', '12', 'Precious V. Gitalan', 'Member', NULL, '3', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('54', '12', 'Grape A. Paquibo', 'Member', NULL, '4', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('55', '12', 'Jerry B. Duco', 'Member', NULL, '5', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('56', '13', 'Paid Umpire', 'Chief Umpire', NULL, '1', '1', '2026-08-17 22:25:08', '2026-08-18 08:21:06');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('57', '13', 'Allen Day Mori', 'Scorer', NULL, '2', '1', '2026-08-17 22:25:08', '2026-08-17 22:30:20');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('59', '13', 'Maria Shednilyn A. Sordilla', 'Member', NULL, '4', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('60', '14', 'Eric Lauron', 'Event Manager', NULL, '1', '1', '2026-08-17 22:28:37', '2026-08-17 22:28:37');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('61', '14', 'Rosaflor G. Canencia', 'Scorer', NULL, '2', '1', '2026-08-17 22:28:37', '2026-08-17 22:28:37');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('62', '14', 'Denmark R. Villa', 'Member', NULL, '3', '1', '2026-08-17 22:28:37', '2026-08-17 22:28:37');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('63', '14', 'Roldan L. Cultura', 'Member', NULL, '4', '1', '2026-08-17 22:28:37', '2026-08-17 22:28:37');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('64', '15', 'Sports In charge', 'Event Manager', NULL, '1', '1', '2026-08-17 22:28:37', '2026-08-17 22:28:37');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('65', '15', 'Nicaster D. Ambalong, Jr.', 'Tournament Manager', NULL, '2', '1', '2026-08-17 22:28:37', '2026-08-17 22:28:37');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('66', '15', 'Mark D. Sildora', 'Member', NULL, '3', '1', '2026-08-17 22:28:38', '2026-08-17 22:28:38');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('67', '15', 'Win Marc C. Cabilan', 'Member', NULL, '4', '1', '2026-08-17 22:28:38', '2026-08-17 22:28:38');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('68', '15', 'TBD', 'Official Announcer', NULL, '5', '1', '2026-08-17 22:28:38', '2026-08-17 22:28:38');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('69', '15', 'BAP', 'Officiating Officials', NULL, '6', '1', '2026-08-17 22:28:38', '2026-08-17 22:28:38');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('70', '15', 'BAP', 'Scorer', NULL, '7', '1', '2026-08-17 22:28:38', '2026-08-17 22:28:38');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('71', '15', 'BAP', 'Timekeeper', NULL, '8', '1', '2026-08-17 22:28:38', '2026-08-17 22:28:38');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('76', '16', 'Roldan Cultura', 'Event Manager (Part 1)', NULL, '1', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('77', '16', 'Khyrthz Marco Salaguste', 'Event Manager (Part 2)', NULL, '2', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('78', '16', 'All SSC Officers', 'Member', NULL, '3', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('79', '16', 'Dirb Boy Sebrero', 'EMCEE', NULL, '4', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('80', '17', 'Ruther Bianan', 'Event Manager', NULL, '1', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('81', '17', 'Richard Lumocas', 'Asst.', NULL, '2', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('82', '17', 'Katreen Glimada', 'Member', NULL, '3', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('83', '17', 'Maricel Fuentes', 'Member', NULL, '4', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('84', '18', 'Rey Pepito', 'Event Manager', NULL, '1', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('85', '18', 'Rosehur Alumbro', 'Asst.', NULL, '2', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('86', '18', 'Lara Jane Espina', 'Member', NULL, '3', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('87', '18', 'Lorejean Pangasian', 'Member', NULL, '4', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('88', '18', 'Sarah Mae Angga', 'EMCEE', NULL, '5', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('89', '19', 'Dirb Boy Sebrero', 'Event Manager', NULL, '1', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('90', '19', 'Win Marc Cabilan', 'Asst.', NULL, '2', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('91', '19', 'Venus Avenido', 'Quizmaster', NULL, '3', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('92', '19', 'Mariell Jun Sanchez', 'Member', NULL, '4', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('93', '19', 'Erma Ambalong', 'Member', NULL, '5', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('94', '19', 'Myrna Perigo', 'Member', NULL, '6', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('95', '20', 'Elberth Rey Dela Cruz', 'Event Manager', NULL, '1', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('96', '20', 'Gilmore Velasco', 'Asst.', NULL, '2', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('97', '20', 'Mayflor Gose', 'Member', NULL, '3', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('98', '20', 'Lanilyn Bustamante', 'Member', NULL, '4', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('99', '21', 'Dyamera Gose', 'Event Manager', NULL, '1', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('100', '21', 'Khyrthz Marco Salaguste', 'Asst.', NULL, '2', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('101', '21', 'BPEd Students', 'Member', NULL, '3', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('102', '21', 'ROTC', 'Member', NULL, '4', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('103', '22', 'Moises Glenn G. Tangalin, Ed.D.', 'Chairperson', NULL, '1', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('104', '22', 'Evelyn M. Daguplo, MBA', 'Vice Chairperson', NULL, '2', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('105', '22', 'Armando S. Buyco, MSCrim', 'Member', 'BSCRIM', '3', '1', '2026-08-17 22:40:24', '2026-08-18 08:36:37');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('106', '22', 'Harvey M. Tangalin', 'Member', 'BSED Engl', '4', '1', '2026-08-17 22:40:24', '2026-08-18 08:36:50');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('107', '22', 'Mariza S. Balatero', 'Member', 'BEED', '5', '1', '2026-08-17 22:40:24', '2026-08-18 08:37:02');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('108', '22', 'Vincent John Chatto', 'Member', 'SCS', '6', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('109', '22', 'Xyrin C. Moñeza', 'Member', 'BSISM', '7', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('110', '22', 'Abundio G. Cabahug, Jr.', 'Member', 'BSA', '8', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('111', '22', 'Sheila L. Bascon', 'Member', 'BSED Math', '9', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('112', '22', 'Buena D. Calunsag, Ed.D.', 'Member', 'BPED', '10', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('113', '22', 'Eleonor N. Ocay, Ph.D.', 'Member', 'Registrar', '11', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('114', '22', 'Eleuteria O. Villarubia', 'Member', 'HR', '12', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('115', '22', 'Mark E. Patalinghug, Ph.D.', 'Member', 'APD', '13', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('116', '23', 'Vincent John L. Chatto', 'Chair', NULL, '1', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('117', '23', 'Richard P. Lumocas', 'V-Chair', NULL, '2', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('118', '23', 'All SCS Faculty', 'Member', NULL, '3', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('119', '23', 'Nelson V. Idias', 'Member', NULL, '4', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('120', '23', 'Myrel Shane C. Abayon', 'Member', NULL, '5', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('121', '23', 'Lorejean E. Pangasian', 'Member', NULL, '6', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('122', '23', 'SCC Officers', 'Member', NULL, '7', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('123', '24', 'Jackie J. Valderama', 'Chair', NULL, '1', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('124', '24', 'School Publication Office', 'Member', NULL, '2', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('125', '25', 'Eric G. Lauron', 'Chair', 'SCS', '1', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('126', '25', 'Rhivee Mae H. Conol', 'V-Chair', 'HS', '2', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('127', '25', 'Sheila L. Bascon', 'Member', 'STE', '3', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('128', '25', 'Haneylyn L. Cagod', 'Member', 'SoCJE', '4', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('129', '25', 'Janice G. Repaso', 'Member', 'SAFES', '5', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('130', '26', 'Chrisia Mae M. Soria', 'Chair', NULL, '1', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('131', '26', 'Jona C. Capangpangan', 'V-Chair', NULL, '2', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('132', '26', 'Karen Joy G. Watin', 'Member', NULL, '3', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('133', '26', 'Kriza Mae D. Bagalanon', 'Member', NULL, '4', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('134', '26', 'Chris John C. Cogalito', 'Member', NULL, '5', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('135', '27', 'Darlin Jane T. Balbastro', 'Chair', NULL, '1', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('136', '27', 'Allen Day S. Mori', 'Member', NULL, '2', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('137', '27', 'SSC Officers', 'Member', NULL, '3', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('138', '28', 'Evelyn M. Daguplo', 'Chair', NULL, '1', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('139', '28', 'Eliezer A. Ocay', 'V-Chair', NULL, '2', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('140', '28', 'Noel S. Veneracion', 'Member', NULL, '3', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('141', '28', 'Jade Mark A. Rupinta', 'Member', NULL, '4', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('142', '28', 'Nelson T. Macot', 'Member', NULL, '5', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('143', '28', 'Rolando C. Dela Torre', 'Member', NULL, '6', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('144', '28', 'Male COS/Field Workers', 'Member', NULL, '7', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('145', '29', 'Evelyn M. Daguplo', 'Chair', NULL, '1', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('146', '29', 'Vincent John L. Chatto', 'V-Chair', NULL, '2', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('147', '29', 'SSC & CSB Officers', 'Member', NULL, '3', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('148', '30', 'Krystelle Joy U. Tangalin', 'Chair', NULL, '1', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('149', '30', 'Junry M. Mangubat', 'V-Chair', NULL, '2', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('150', '30', 'Mark D. Sildora', 'Member', NULL, '3', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('151', '30', 'Jennie Ree B. Pan', 'Member', NULL, '4', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('152', '30', 'DRRMO', 'Member', NULL, '5', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('153', '31', 'Vicente E. Ebisa', 'Chair', NULL, '1', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('154', '31', 'All Security Guards', 'Member', NULL, '2', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('155', '32', 'Gemma B. Delicana', 'Chair', NULL, '1', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('156', '32', 'Orlando T. Hentica', 'Member', NULL, '2', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('157', '32', 'Benilda K. De Jose', 'Member', NULL, '3', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('158', '32', 'Noel E. Adaza', 'Member', NULL, '4', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('159', '32', 'John C. Macaranas', 'Member', NULL, '5', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('160', '33', 'Buena D. Calunsag', 'Chair', NULL, '1', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('161', '33', 'BPED Students', 'Member', NULL, '2', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('162', '34', 'Marjorey C. Cabigas', 'Socio-Cultural Events', NULL, '1', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('163', '34', 'Steven J. Tres Reyes', 'Sports Competitions', NULL, '2', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('164', '35', 'Moises Glenn G. Tangalin, Ed.D.', 'Chairperson', NULL, '1', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('165', '35', 'Mark E. Patalinghug, Ph.D.', 'Vice Chairperson', NULL, '2', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('166', '35', 'Xyrin C. Moñeza, MSCrim', 'Vice Chairperson', NULL, '3', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('167', '35', 'Tournament Managers', 'Member', NULL, '4', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('168', '35', 'Tournament Officials', 'Member', NULL, '5', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('169', '35', 'Team Managers', 'Member', NULL, '6', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('170', '35', 'Sports In-charge', 'Member', NULL, '7', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('171', '35', 'Socio-Cultural In-charge', 'Member', NULL, '8', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committee_members` (`id`, `committee_id`, `full_name`, `position_title`, `organization`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('172', '22', 'Venus M. Avenido, RGC', 'Member', 'OSAS Dean', '14', '1', '2026-08-18 08:25:44', '2026-08-18 08:25:44');

-- --------------------------------------------------------
-- Table: `working_committees`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `working_committees`;
CREATE TABLE `working_committees` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `category` enum('overall','sporting_events','socio_cultural') NOT NULL DEFAULT 'overall',
  `description` text DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_working_committee_name` (`name`),
  KEY `idx_wc_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('1', 'VOLLEYBALL Men', 'sporting_events', NULL, '1', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('2', 'VOLLEYBALL Women', 'sporting_events', NULL, '2', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('3', 'SEPAK TAKRAW Men', 'sporting_events', NULL, '3', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('4', 'ESPORTS Men & Women', 'sporting_events', 'Game: MLBB / CODM', '4', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('5', 'TABLE TENNIS (Single/Double) Men', 'sporting_events', NULL, '5', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('6', 'TABLE TENNIS (Single/Double) Women', 'sporting_events', NULL, '6', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('7', 'BADMINTON (Single/Double) Men & Women', 'sporting_events', NULL, '7', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('8', 'LAWN TENNIS (Single/Double) Men & Women', 'sporting_events', NULL, '8', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('9', 'PICKLEBALL (Double/Mix) Men & Women', 'sporting_events', NULL, '9', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('10', 'ATHLETICS Men & Women', 'sporting_events', NULL, '10', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('11', 'CHESS Men & Women', 'sporting_events', NULL, '11', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('12', 'BASEBALL Men', 'sporting_events', NULL, '12', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('13', 'SOFTBALL Women', 'sporting_events', NULL, '13', '1', '2026-08-17 22:25:08', '2026-08-17 22:25:08');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('14', 'FRISBEE Mix', 'sporting_events', NULL, '14', '1', '2026-08-17 22:28:37', '2026-08-17 22:28:37');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('15', 'BASKETBALL Competition', 'sporting_events', '5x5 / 3x3 Men & Women', '15', '1', '2026-08-17 22:28:37', '2026-08-17 22:28:37');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('16', 'Opening Program', 'socio_cultural', 'Venue: Open Stage\nAugust 24, 2026 @ 8am\nPart 1. Opening Program\nPart 2. Power Dance Competition', '1', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('17', 'Visual Arts', 'socio_cultural', 'August 24, 2026 @ 1pm\nVenue: BEED Rooms & Open Grounds', '2', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('18', 'Literary Arts', 'socio_cultural', 'August 24, 2026 @ 1pm\nVenue: Research Office\nExtemporaneous Speaking, Storytelling, Dagliang Talumpati, Pagkukuwento', '3', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('19', 'Quiz Bowl', 'socio_cultural', 'August 25, 2026 @ 8am\nVenue: AVR', '4', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('20', 'Music', 'socio_cultural', 'August 25, 2026 @ 1pm\nVenue: Function Hall\nSolo (Pop), Duet (Pop), Kundiman', '5', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('21', 'Dance Arts and DanceSport', 'socio_cultural', 'Dance Arts (Folk, Street, Contemporary)\nDanceSport (Modern Standard, Latin American, Third Kind)', '6', '1', '2026-08-17 22:36:58', '2026-08-17 22:36:58');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('22', 'STEERING COMMITTEE', 'overall', NULL, '1', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('23', 'PROGRAM, CERTIFICATES, AWARDS AND INVITATIONS', 'overall', NULL, '2', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('24', 'MARKETING AND MEDIA', 'overall', NULL, '3', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('25', 'TABULATORS', 'overall', 'Socio-Cultural Competitions', '4', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('26', 'SECRETARIAT', 'overall', NULL, '5', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('27', 'COMMUNICATIONS', 'overall', NULL, '6', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('28', 'VENUE AND PLAYING COURT PREPARATION', 'overall', 'Sports Competition', '7', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('29', 'DECORATION', 'overall', 'Opening Program', '8', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('30', 'HEALTH AND MEDICAL SERVICES', 'overall', NULL, '9', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('31', 'PEACE AND ORDER', 'overall', NULL, '10', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('32', 'CLEANLINESS AND SANITATION', 'overall', NULL, '11', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('33', 'SNACKS AND MEALS', 'overall', NULL, '12', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('34', 'OVERALL EVENT MANAGER', 'overall', NULL, '13', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');
INSERT INTO `working_committees` (`id`, `name`, `category`, `description`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES ('35', 'SPECIAL ARBITRARY COMMITTEE', 'overall', NULL, '14', '1', '2026-08-17 22:40:24', '2026-08-17 22:40:24');

SET FOREIGN_KEY_CHECKS = 1;
